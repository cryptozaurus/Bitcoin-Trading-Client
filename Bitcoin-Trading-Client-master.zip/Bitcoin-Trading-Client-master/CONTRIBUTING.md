#Contributing Guidlines

This project is completely open source, and it is my hope that people will contribute to help make it into something great.

All of the following contributions are wanted:
-General functionality concepts and ideas
-Code fixes and new implementations
-Typo corrections
-Readme improvement

All changes must come with complete explanations as to the reason and purpose for the change. 

